# Developers guide
This guide will walk you through setting up your development environment, building your project package, enabling remote installations, and starting your local server for testing.

## Setting up an environment

In your projects root directory go to: `build/dev_env.json`.

1. `release_folder` A location where your package will be saved. **IT MUST BE IN THE ROOT FOLDER OF YOUR PROJECT!**
2. `build_save_format`A format in which your package will be saved ex. `<name>_<version>`. This is pulled from your manifest. Supported placeholders are `<name>, <version>, <description>, <author>, <license>`.
3. `address` Remote address of your AWT instance. This is used for quick deployment of your packages.
4. `remote_install_path` Remote path on your AWT instance, where packages will be pushed.
5. `devSecret` A secret key that allows you to "securely" install your package on remote instance.

## How to build your package

### Windows

In your projects root directory simply run `build.bat`.

### Linux

Go to your projects root directory and in terminal type:
`./build.sh`. If it fails in terminal type `sudo chmod +x ./build.sh'. Then run it again with `./build.sh`.


## How to enable remote installation.

This setting is intended for development purposes only. It MUST remain FALSE in production environments to ensure security.


In `awt_config.php` set the following:
```
const DEBUG = true;
const REMOTE_INSTALL_FOR_DEVS = true;
const DEV_SECRET = ""; <- make sure this matches your devSecret in dev_env.json
```

**BE CAUTIOUS WHEN ENABLING THIS. It's unsecure since it cant authenticate you if you are and admin or not and it is exposed to public.**
**ALWAYS ENABLE THIS IN LOCAL PRODUCTION**.

## How to start local server for development.

### Windows
1. Go to your AWT installation directory.
2. Go to `/dev_run/`.
3. Run `run.bat`.

### Linux
1. `cd <installation directory>` cd into your AWT.
2. `cd ./dev_run`
3. `sudo chmod +x ./run.sh`
4. `./run.sh`